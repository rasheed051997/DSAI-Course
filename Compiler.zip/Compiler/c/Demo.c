#include <stdio.h>
 
int main()
{
	int c;
	scanf(&c);
	printf("%d",c);
	return 0;
}
 
