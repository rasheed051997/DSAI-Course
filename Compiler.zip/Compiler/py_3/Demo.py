a=1 
def func():
  b=2
  print(a)
  print(b)
func()
print(a)
print(b)